#!/bin/sh

ERR_CODE="128"
big="50"
equal="40"
small="30"


main_module="scangearmp"
common="common"
version="1.30-1"
arch="i386"

copyright1="ScanGear MP Ver.$version for Linux"
copyright2="Copyright CANON INC. 2007-2009"
copyright3="All Rights Reserved."

install_script_fname="install.sh"
config_path_rpm="/usr/local/bin"
config_path_deb="/usr/bin"

err_msg1="Error! Cannot specify package management system."
err_msg2="Error! The appropriate package is not found in the appropriate directory."
err_msg3="Usage: ${0##*/} [ --uninstall | --version ]"

show_and_exec()
{
	echo "Execution command = $1"
	$1
}

version_comp()
{
	makelist()
	{
		echo $1
		echo $2
	}
			onlyfname=`echo ${filename##*/}`

	## version compare ##
	# ex. 3.10->310, 1.30->130 #
	tmpstr=`echo ${1%%-*}`
	ver1=`echo ${tmpstr%%.*}``echo ${tmpstr##*.}`
	tmpstr=`echo ${2%%-*}`
	ver2=`echo ${tmpstr%%.*}``echo ${tmpstr##*.}`

	# ex. 310 > 300  #
	if [ $ver1 -gt $ver2 ]; then
		return $big
	elif [ $ver1 -lt $ver2 ]; then
		return $small
	fi
	
	## release compare ##
	# ex. a13->[a][13], 2->[][2] #
	tmpstr=`echo ${1##*-}`
	rela1=`echo ${tmpstr%%[0-9]*}`
	reln1=`echo ${tmpstr##*[a-z]}`
	tmpstr=`echo ${2##*-}`
	rela2=`echo ${tmpstr%%[0-9]*}`
	reln2=`echo ${tmpstr##*[a-z]}`

	# ex. [a][13] < [][2] #
	if [ -z $rela1 ] && [ -n $rela2 ]; then
		return $big
	elif [ -n $rela1 ] && [ -z $rela2 ]; then
		return $small
	fi
	
	# ex. [a][2] < [b][1] #
	if [ -n $rela1 ] && [ $rela1 != $rela2 ]; then
		list=`makelist $rela1 $rela2 | sort`
		for tmpstr in $list; do
			if [ $tmpstr = $rela1 ]; then
				return $small
			else
				return $big
			fi
		done
	fi
	
	# ex. [a][2] > [a][1], [b][9] < [b][10] #
	if [ $reln1 -gt $reln2 ]; then
		return $big
	elif [ $reln1 -lt $reln2 ];then
		return $small
	else
		return $equal
	fi
}

######################################################
#### _ _ E x e c u t e _ I n s t a l l . s h  _ _ ####
######################################################
if [ ${0##*/} = $install_script_fname ]; then

	#################################################################
	#### _ _ B o t h _ P a c k a g e _ C o m m o n _ F l o w _ _ ####
	#################################################################

    #################################
	### Judge distribution system ###
    #################################

	## Judge is the distribution supporting rpm? ##
	rpm --version 1> /dev/null 2>&1
	system_rpm=$?

	## Judge is the distribution supporting dpkg(debian)? ##
	dpkg --version 1> /dev/null 2>&1
	system_deb=$?

	## rpm and deb are error, or rpm and deb are no error, is error ##
	if [ $system_rpm = 0 -a $system_deb = 0 ] || [ $system_rpm != 0 -a $system_deb != 0 ]; then
		echo $err_msg1
		exit
	else
		if test $system_rpm -eq 0; then
			system="rpm"
		else
			system="deb"
		fi
	fi

    ############################
	### Check file structure ###
    ############################

	## Get full path of script and packages ##
	pkg_path=`echo $(dirname $0)`/packages
	if [ ! -d $pkg_path ]; then
		echo $err_msg2
		exit
	fi

	## Count total files and check the filename ##
	file_cnt=0
	files=$pkg_path/*
	for filename in $files; do
		if [ $filename != $pkg_path ]; then
			# Count number of files           #
			file_cnt=`expr $file_cnt + 1`
			
			# Get only file name              #
			onlyfname=`echo ${filename##*/}`
			# Check the extension, and the filename for module #
			if [ `echo ${onlyfname##*.}` != $system -o `echo ${onlyfname%%-*}` != $main_module ]; then
				echo $err_msg2
				exit
			fi

			# Get device name(ex.mx860series) #
			tmpstr1=`echo ${onlyfname##$main_module-}`
			if [ $system = "rpm" ]; then
				if [ `echo ${tmpstr1%%-$version*}` != $common ]; then
					device=`echo ${tmpstr1%%-$version*}`
				fi
			else
				if [ `echo ${tmpstr1%%_$version*}` != $common ]; then
					device=`echo ${tmpstr1%%_$version*}`
				fi
			fi
		fi
	done

	## Check number of files ##
	if [ $file_cnt -gt 2 ]; then
		echo $err_msg2
		exit
	fi

	## Recheck package names ##
	pkgname_common=$main_module-$common
	pkgname_depend=$main_module-$device
	if [ $system = "rpm" ]; then
		fpath_common=$pkg_path/$pkgname_common-$version.$arch.$system
		fpath_depend=$pkg_path/$pkgname_depend-$version.$arch.$system
	else
		fpath_common=$pkg_path/${pkgname_common}_${version}_$arch.$system
		fpath_depend=$pkg_path/${pkgname_depend}_${version}_$arch.$system
	fi

	## Check having common and depend package files ##
	if test ! -f $fpath_common; then
		echo $err_msg2
		exit
	fi
	if test ! -f $fpath_depend; then
		echo $err_msg2
		exit
	fi


	#####################################################################
	#### _ _ P a c k a g e _ S y s t e m _ D e p e n d _ F l o w _ _ ####
	#####################################################################

	rpm_install_process()
	{
		fpath_pkg_name=$1
		pkg_name=$2
		exec_update=1
		
		## result -> 0:Package installed, 1:Package not installed ##
		installed_pkg=`rpm -q $pkg_name`
		if [ $? -eq 0 ]; then
			installed_pkg_ver=`echo ${installed_pkg##$pkg_name-}`
			installed_pkg_ver=`echo ${installed_pkg_ver%%.$arch}`
			version_comp $installed_pkg_ver $version
			if [ $? -ne $small ]; then
				exec_update=0
			fi
		fi

		if [ $exec_update -eq 1 ]; then
			show_and_exec "rpm -Uvh $fpath_pkg_name"
			if [ $? -ne 0 ]; then
				return $ERR_CODE
			fi
		else
			show_and_exec "rpm --test -U $fpath_pkg_name"
		fi

		return 0	
	}

	deb_install_process()
	{
		fpath_pkg_name=$1

		## result -> 0:Install process complete, 1:Install process depend error ##
		show_and_exec "sudo dpkg -iG $fpath_pkg_name"
		if [ $? != 0 ]; then
			return $ERR_CODE
		fi
		
		return 0
	}

	## Make Package-config script, after Check Newer version config script is installed already ##
	make_pkgconfig()
	{
		script_path=$3
		pkgconfig_fname=$main_module-$1-$2-pkgconfig.sh
		pkgconfig_fpath="$script_path/$pkgconfig_fname"

		if [ ! -d /usr ]; then
			mkdir /usr
		fi
		if [ $2 = "rpm" ]; then
			if [ ! -d /usr/local ]; then
				mkdir /usr/local
			fi
			config_path=$config_path_rpm
		else
			config_path=$config_path_deb
		fi
		if [ ! -d $config_path ]; then
			mkdir $config_path
		fi

		$sudo_command cp -af $(dirname $0)/$install_script_fname $pkgconfig_fpath

		## Change file permission to same install.sh ##
		$sudo_command chmod 755 $pkgconfig_fpath
		$sudo_command chown root $pkgconfig_fpath
		$sudo_command chgrp root $pkgconfig_fpath
	}

	if [ $system = "rpm" ]; then
		install_process="rpm_install_process"
		uninstall_command="rpm -e"
		script_path=$config_path_rpm
		sudo_command=""
		
		##  Check permission by root ##
		if test `id -un` != "root"; then
			su -c $0
			exit
		fi
	else
		install_process="deb_install_process"
		uninstall_command="sudo dpkg -P"
		script_path=$config_path_deb
		sudo_command="sudo"
	fi

	## Common-Package install process ##
	$install_process $fpath_common $main_module-$common
	if [ $? -ne 0 ]; then
		exit
	fi
		
	## Depend-Package install process ##
	$install_process $fpath_depend $main_module-$device
	if [ $? -ne 0 ]; then
		show_and_exec "$uninstall_command $pkgname_common"
		exit
	fi
		
	pkgconfig_fname=$main_module-$device-$system-pkgconfig.sh
	$pkgconfig_fname --pkgconfig 1> /dev/null 2>&1
	if [ $? -ne 0 ]; then
		make_pkgconfig $device $system $script_path
	else
		installed_config_ver=`$pkgconfig_fname --pkgconfig`
		version_comp $installed_config_ver $version
		if [ $? -lt $equal ]; then
			$sudo_command rm -rf $script_path/$pkgconfig_fname
			make_pkgconfig $device $system $script_path
		fi
	fi
	
	echo "## Install $device process is complete ! ##"


##########################################################
#### _ _ E x e c u t e _ P k g c o n f i g . s h  _ _ ####
##########################################################
else
	argment=$1

	## Check the argment ##
	if [ $# -ne 1 ]; then
		echo $err_msg3
		exit
	elif [ $argment != "--version" ] && [ $argment != "--uninstall" ] && [ $argment != "--pkgconfig" ]; then
		echo $err_msg3
		exit
	fi

	########################
	### Unistall process ###
	########################
	if [ $argment = "--uninstall" ]; then
	
		intermediate=${0##*$main_module-}
		device=${intermediate%%-*}
		intermediate=${0##*$device-}
		system=${intermediate%%-*}

		rpm_uninstall_process()
		{
			rpm -q $1 1> /dev/null 2>&1
			## result -> 0:Package installed, 1:Package not installed ##
			if [ $? -eq 0 ]; then
				# uninstall #
				show_and_exec "rpm -e $1"
				## result -> 0:Uninstall complete, 1:Uninstall error by debendency ##
				if [ $? -ne 0 ]; then
					# Dependency error #
					return $ERR_CODE
				fi
			fi
			return 0
		}

		deb_uninstall_process()
		{
			# uninstall #
			show_and_exec "sudo dpkg -P $1"
			## result -> 0:Uninstall complete, 1:Uninstall error by debendency ##
			if [ $? -ne 0 ]; then
				# Dependency error #
				return $ERR_CODE
			fi
			
			return 0
		}

		if [ $system = "rpm" ]; then
			uninstall_process="rpm_uninstall_process"
			sudo_command=""
			
			##  Check permission by root ##
			if test `id -un` != "root"; then
				su -c "$0 $argment"
				exit
			fi
		else
			uninstall_process="deb_uninstall_process"
			sudo_command="sudo"
		fi

		##  Uninstall Depend-Package ##
		depend_pkg_name=
		$uninstall_process $main_module-$device
		if [ $? -ne 0 ]; then
			exit
		fi

		##  Delete mine (pkgconfig.sh)  ##
		$sudo_command rm -rf $(dirname $0)/${0##*/}

		##  Uninstall Common-Package ##
		$uninstall_process $main_module-$common

		echo "## Uninstall $device process is complete ! ##"

	###############################
	### Version display process ###
	###############################
	elif [ $argment = "--version" ]; then

		intermediate=${0##*$main_module-}
		device=${intermediate%%-*}
		intermediate=${0##*$device-}
		system=${intermediate%%-*}

		echo ; echo $copyright1; echo $copyright2; echo $copyright3
		echo ; echo "[Packages]"
		
		if [ $system = "rpm" ]; then
			echo $main_module-$common-$version.$arch.$system
			echo $main_module-$device-$version.$arch.$system
		else
			echo $main_module-${common}_${version}_$arch.$system
			echo $main_module-${device}_${version}_$arch.$system
		fi
		echo

	elif [ $argment = "--pkgconfig" ]; then
		echo $version
	fi

fi
